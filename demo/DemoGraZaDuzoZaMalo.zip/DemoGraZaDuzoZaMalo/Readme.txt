Przyk�ad (zrealizowany na szybko).
1. Gra w dw�ch wariantach - konsolowym (CLI) oraz okienkowym (WinForm)
2. Obie wersje bazuj� na wsp�lnym modelu gry Gra.Model.dll
